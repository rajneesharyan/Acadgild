# Language-Translation

This is the fourth project in my Deep Learning Nanodegree Foundation (Udacity). Using the template provided by Udacity, I added the necessary code to build a sequence-to-sequence neural network, with TensorFlow, that can translate text from English to French.

The easiest way to view my work is to look at the .ipynb file.

helper.py contains helper functions that were provided by Udacity.

problem_unittests.py contains tests to ensure that I am correctly building my model as I progress through the project; provided by Udacity.
